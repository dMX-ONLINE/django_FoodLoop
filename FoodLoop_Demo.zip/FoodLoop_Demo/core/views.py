from django.shortcuts import render

# Create your views here.

def welcome(request):
    return render(request, 'core/welcome.html')

def index(request):
    return render(request, "core/index.html")

def about(request):
    return render(request, "core/about.html")

